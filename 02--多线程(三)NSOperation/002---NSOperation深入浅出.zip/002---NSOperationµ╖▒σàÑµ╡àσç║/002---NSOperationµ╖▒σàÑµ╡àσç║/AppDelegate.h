//
//  AppDelegate.h
//  002---NSOperation深入浅出
//
//  Created by Cooci on 2018/7/4.
//  Copyright © 2018年 Cooci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

